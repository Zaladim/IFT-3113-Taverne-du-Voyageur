﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestClient : MonoBehaviour
{
    public enum State
    {
        FindingSeat,
        WaitingToOrder,
        WaitingToReciveOrder,
        Eating,
        WaitingToPay,
        Leaving,
        Inactive
    }

    private BasicAI mouvement;

    private TextMesh text;

    private TextMesh subText;

    private Seat seat;

    private Entrance exit;

    private State etat;

    public float timeToEat;

    private float timeLeftToEat;


    // Start is called before the first frame update
    void Start()
    {
        mouvement = GetComponent<BasicAI>();
        Transform temp = GetComponent<Transform>().Find("Text");
        text = temp.GetComponent<TextMesh>();
        temp = GetComponent<Transform>().Find("SubText");
        subText = temp.GetComponent<TextMesh>();
        etat = State.FindingSeat;
    }

    // Update is called once per frame
    void Update()
    {
        if (etat == State.FindingSeat)
        {
            text.text = "Finding Seat";
            if (seat == null)
            {
                subText.text = "Seat Not Found";
                seat = mouvement.GoToRandomSeat();
            }
            else
            {
                subText.text = "Seat Found";
                if (mouvement.isAtLocation(seat.transform.position))
                {
                    seat.isOccupied = true;
                    transform.rotation = Quaternion.Euler(0f, 0f, 0f);
                    etat = State.WaitingToOrder;
                }
            }
        }
        else if (etat == State.WaitingToOrder)
        {
            text.text = "Waiting To Order";
            subText.text = "Press Enter";
            if (Input.GetKeyDown(KeyCode.Return))
            {
                etat = State.WaitingToReciveOrder;
            }
        }
        else if (etat == State.WaitingToReciveOrder)
        {
            text.text = "Waiting To Recive Order";
            subText.text = "Press Enter";
            if (Input.GetKeyDown(KeyCode.Return))
            {
                etat = State.Eating;
                timeLeftToEat = timeToEat;
            }
        }
        else if (etat == State.Eating)
        {
            text.text = "Eating";
            subText.text = "Time Left: " + Mathf.Ceil(timeLeftToEat).ToString() + "s";
            timeLeftToEat -= Time.deltaTime;
            if (timeLeftToEat <= 0)
            {
                etat = State.WaitingToPay;
            }
        }
        else if (etat == State.WaitingToPay)
        {
            text.text = "Waiting To Pay";
            subText.text = "Press Enter";
            if (Input.GetKeyDown(KeyCode.Return))
            {
                etat = State.Leaving;
            }
        }
        else if (etat == State.Leaving)
        {
            text.text = "Leaving";
            if (seat != null)
            {
                subText.text = "Exit Not Found";
                seat.isAIGoingForIt = false;
                seat.isOccupied = false;
                seat = null;
                exit = mouvement.GoToExit();
            }
            else
            {
                if (exit == null)
                {
                    subText.text = "Exit Not Found";
                    exit = mouvement.GoToExit();
                }
                else
                {
                    subText.text = "Exit Found";
                    if (mouvement.isAtLocation(exit.transform.position))
                    {
                        transform.rotation = Quaternion.Euler(0f, 0f, 0f);
                        etat = State.Inactive;
                    }
                }
            }
        }
        else if (etat == State.Inactive)
        {
            text.text = "Inactive";
            subText.text = "Press Enter";
            if (Input.GetKeyDown(KeyCode.Return))
            {
                etat = State.FindingSeat;
            }
        }
    }
}
